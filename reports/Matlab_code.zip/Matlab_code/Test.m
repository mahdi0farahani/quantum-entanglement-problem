clc
clear

%Matlab test
addpath(genpath('C:\Users\mahdi\Desktop\QETLAB-0.9'));
d1 = 3;
d2 = 3;
num_e= 0; %number of entangled that is not PPT
q= 0; %number of seprable
p= 0; %number of PPT
n_sep = 2000; %number of seprable
n_sta = 5000; %number of states
n_ent = 20; %number of entangled that not PPT
%ket1 = kron(RandomStateVector(d1), RandomStateVector(d2));
%ket1 = eye(3,3)./2;
%rho = ket1 * ket1';
%rho = RandomDensityMatrix(9);
%list1 = generate_rand_den_list(d1,10);
%list2 = generate_rand_den_list(d2,10);
Data = zeros(n_sta+1,81);
for z = 1:n_sep
    rho  = SeprableState(d1,d2,8);
    vrho = DMToVec(rho);
    label = 0;
    Data(z+1,:) = [transpose(vrho),label];
end
z = n_sep+1;
while num_e<n_ent
    %rho  = SeprableState(d1,d2,8);
    rho = RandomDensityMatrix(9);
    vrho = DMToVec(rho);
    PPT = IsPPT(rho);
    if PPT == 0 && p<n_sta- n_ent
        z= z+1;
        p= p+1;
        label = 1;
        Data(z+1,:) = [transpose(vrho),label];
   
    elseif PPT == 1
        dim = d1*d1*d2*d2 - 1;
        init = dim * 80;
        kets = zeros(d1 * d2, init);
        points = zeros(init, dim);
        parfor i = 1 : init
            kets(:, i) = kron(RandomStateVector(d1), RandomStateVector(d2));
            points(i, :) = DMToVec(kets(:, i) * kets(:, i)');
        end

        [ans1, x] = CompAlpha(vrho, points);
        kets = kets(:, x);
        points = points(x, :);
        eps = 1;
        %disp(ans);
        iter = 0;
        maxiter = 10;
        rate = 1;
        while 1
            if ans1 >= 1
                label = 0;%seperable
                q = q+1;
                break;
            end
            if iter == maxiter
                z= z+1;
                label = 1;%entangled
                num_e = num_e+1;
                Data(z+1,:) = [transpose(vrho),label];
                break;
            end
            iter = iter + 1;
            n = size(points, 1);
            for i = 1 : n
                for j = 1: 10
                    U1 = Random_Unitary(d1, rand * eps);
                    U2 = Random_Unitary(d2, rand * eps);
                    ket = kron(U1, U2) * kets(:, i);
                    kets = [kets ket];
                    points = [points; transpose(DMToVec(ket * ket'))];
                end
            end
            %fprintf('WOW Its rotating');
            %disp(iter);
            [ans1, x] = CompAlpha(vrho, points);
            kets = kets(:, x);
            points = points(x, :);
            %msg = sprintf('p_c = %.8f', ans);
            %	disp(msg);
            eps = eps * rate;
        end
        %fprintf('YES!');
        
    end
end



